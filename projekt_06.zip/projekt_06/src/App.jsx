import './App.css';
import Axios from "axios";
import { useEffect, useState } from 'react';

function App() {

  const [officialJoke, setOfficialJoke] = useState("");

  const fetchOfficialJoke = () => {
    Axios.get("https://official-joke-api.appspot.com/random_joke").then((res) => {
      setOfficialJoke(res.data.setup + res.data.punchline);
    });
  };

  /*https://official-joke-api.appspot.com/random_joke*/ 
  useEffect(() => {
    fetchOfficialJoke();
  }, []);

  return (
    <div className="App">
      <div className="joke">
      </div>

      <button onClick={fetchOfficialJoke}>Generate Official Joke</button>
      <p>{officialJoke}</p>
    </div>
  );
  
}

export default App
